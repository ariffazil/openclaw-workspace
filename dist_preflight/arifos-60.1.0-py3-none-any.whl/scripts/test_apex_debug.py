"""Debug APEX verdict."""
import asyncio
from aaa_mcp.tools.canonical_trinity import mcp_init, mcp_agi, mcp_asi, mcp_apex

async def test():
    print("Debugging APEX verdict...")
    
    init_result = await mcp_init(query="What is the capital of Malaysia?")
    session_id = init_result['session_id']
    
    agi_result = await mcp_agi(action="reason", query="What is the capital of Malaysia?", session_id=session_id)
    print(f"AGI verdict: {agi_result.get('verdict')}, vote: {agi_result.get('vote')}")
    
    asi_result = await mcp_asi(action="empathize", query="What is the capital of Malaysia?", session_id=session_id)
    print(f"ASI verdict: {asi_result.get('verdict')}, vote: {asi_result.get('vote')}")
    print(f"ASI empathy_kappa_r: {asi_result.get('empathy_kappa_r')}")
    print(f"ASI peace_squared: {asi_result.get('peace_squared')}")
    
    apex_result = await mcp_apex(
        action="judge",
        query="What is the capital of Malaysia?",
        session_id=session_id,
        agi_result=agi_result,
        asi_result=asi_result
    )
    print(f"\nAPEX verdict: {apex_result.get('verdict')}")
    print(f"APEX trinity_score: {apex_result.get('trinity_score')}")
    print(f"APEX final_verdict: {apex_result.get('final_verdict')}")

if __name__ == "__main__":
    asyncio.run(test())
